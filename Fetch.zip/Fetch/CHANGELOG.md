# Changelog

Version goes up with every round of changes (`versionCode` / `versionName` in `app/build.gradle.kts`).

## 1.1 (versionCode 2)
- Package / applicationId renamed to `com.fetch.app` to match the app name. Android sees this as a new app, so uninstall the old build once.
- Cache optimised: leftover download files are wiped on every start, thumbnail cache is capped at 24 MB, new menu item **Clear cache**.
- Display locked to the phone's highest refresh rate (60 / 90 / 120 Hz) and re-applied on resume.
- Header now reads **Fetch by Ranweir** (themed for light and dark); tapping it opens https://t.me/ranweirsinventory.

## 1.0 (versionCode 1)
- First release.
