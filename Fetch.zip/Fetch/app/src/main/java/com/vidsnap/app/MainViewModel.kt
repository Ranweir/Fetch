package com.vidsnap.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("vidsnap", Context.MODE_PRIVATE)

    var url by mutableStateOf("")
    var loading by mutableStateOf(false)
    var meta by mutableStateOf<VideoMeta?>(null)
    var quality by mutableStateOf<Quality>(Quality.Best)
    var message by mutableStateOf<String?>(null)

    var themeMode by mutableStateOf(
        ThemeMode.values().getOrElse(prefs.getInt("theme", 0)) { ThemeMode.SYSTEM }
    )
        private set

    fun setTheme(mode: ThemeMode) {
        themeMode = mode
        prefs.edit().putInt("theme", mode.ordinal).apply()
    }

    fun fetch() {
        val link = url.trim()
        if (link.isBlank() || loading) return
        loading = true
        meta = null
        viewModelScope.launch {
            try {
                val m = DownloadManager.fetchInfo(link)
                meta = m
                quality = Quality.Best
            } catch (e: Exception) {
                message = "Couldn't read this link: ${(e.message ?: "unknown error").take(300)}"
            } finally {
                loading = false
            }
        }
    }

    fun download() {
        val m = meta ?: return
        DownloadManager.enqueue(m, quality)
        message = "Download started"
        meta = null
        url = ""
    }

    fun updateEngine() {
        viewModelScope.launch {
            message = "Updating engine…"
            message = Engine.update(getApplication())
        }
    }

    fun clearInstagramLogin() {
        DownloadManager.clearInstagramLogin()
        message = "Instagram login removed"
    }

    /** Called when a link is shared into the app. */
    fun onSharedText(text: String) {
        val found = Regex("https?://\\S+").find(text)?.value ?: return
        url = found
        fetch()
    }
}
