package com.vidsnap.app

import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/** Small helpers: short-link resolving, clean error text and a direct-media fallback scraper. */
object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"

    class Page(val finalUrl: String, val body: String)
    class Probe(val total: Long, val ranges: Boolean, val finalUrl: String)

    private const val CHUNK = 1024L * 1024L

    private val PIN_ID = Regex("""/pin/(?:[^/?#]*--)?(\d+)""")
    private val MEDIA = Regex(
        """https?://[^\s"'<>\\]+?\.(?:mp4|m3u8|webm|mov)(?:/?\?[^\s"'<>\\]*|/)?""",
        RegexOption.IGNORE_CASE
    )
    private val HEIGHT = Regex("""(\d{3,4})p""")

    fun origin(url: String): String? = try {
        val u = URI(url)
        "${u.scheme}://${u.host}/"
    } catch (_: Exception) {
        null
    }

    /** Keeps the useful ERROR line of yt-dlp output instead of the first warning. */
    fun cleanError(msg: String?): String {
        if (msg.isNullOrBlank()) return "Unknown error"
        val lines = msg.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return "Unknown error"
        val line = lines.lastOrNull { it.startsWith("ERROR") } ?: lines.last()
        return line.removePrefix("ERROR:").trim().take(280)
    }

    /** Expands pin.it short links, strips tracking from Instagram links. */
    fun resolve(raw: String): String {
        val url = raw.trim()
        val host = try {
            URI(url).host?.lowercase().orEmpty()
        } catch (_: Exception) {
            ""
        }
        return when {
            host == "pin.it" -> {
                val final = followRedirects(url)
                var id = PIN_ID.find(final)?.groupValues?.get(1)
                if (id == null) {
                    val page = get(final)
                    id = page?.let { PIN_ID.find(it.finalUrl)?.groupValues?.get(1) ?: PIN_ID.find(it.body)?.groupValues?.get(1) }
                }
                if (id != null) "https://www.pinterest.com/pin/$id/" else final
            }
            host.contains("pinterest.") -> {
                val id = PIN_ID.find(url)?.groupValues?.get(1)
                if (id != null) "https://www.pinterest.com/pin/$id/" else url
            }
            host.endsWith("instagram.com") -> url.substringBefore("?").substringBefore("#")
            else -> url
        }
    }

    /** Follows redirects by hand with a real browser User-Agent (pin.it rejects bots). */
    fun followRedirects(start: String, maxHops: Int = 8): String {
        var current = start.replace(Regex("^http://"), "https://")
        for (i in 0 until maxHops) {
            if (PIN_ID.containsMatchIn(current)) return current
            val conn = URL(current).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15_000
                conn.readTimeout = 20_000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location") ?: return current
                    current = URL(URL(current), loc).toString()
                } else {
                    return current
                }
            } catch (_: Exception) {
                return current
            } finally {
                conn.disconnect()
            }
        }
        return current
    }

    fun get(url: String, referer: String? = null, cookie: String? = null): Page? {
        val conn = try {
            URL(url.replace(Regex("^http://"), "https://")).openConnection() as HttpURLConnection
        } catch (_: Exception) {
            return null
        }
        return try {
            conn.instanceFollowRedirects = true
            conn.connectTimeout = 15_000
            conn.readTimeout = 25_000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            if (referer != null) conn.setRequestProperty("Referer", referer)
            if (cookie != null) conn.setRequestProperty("Cookie", cookie)
            if (conn.responseCode != 200) return null
            val out = ByteArrayOutputStream()
            conn.inputStream.use { ins ->
                val buf = ByteArray(8192)
                var total = 0
                while (total < 3_000_000) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    total += n
                }
            }
            Page(conn.url.toString(), out.toString("UTF-8"))
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun heightOf(u: String): Int {
        val h = HEIGHT.find(u)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        return if (h in 140..4400) h else 0
    }

    private fun meta(html: String, prop: String): String? =
        Regex("""<meta[^>]+(?:property|name)=["']$prop["'][^>]+content=["']([^"']*)["']""", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)

    /** Last resort: look for a direct .mp4/.m3u8/.webm link inside the page source. */
    fun scrapeDirect(pageUrl: String, cookie: String? = null): VideoMeta? {
        val page = get(pageUrl, referer = pageUrl, cookie = cookie) ?: return null
        val text = page.body
            .replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")

        val candidates = MEDIA.findAll(text).map { it.value }
            .filter { c ->
                val l = c.lowercase()
                !l.contains("thumb") && !l.contains("preview") && !l.contains("sprite") &&
                    !l.contains("/ads/") && !l.contains("trailer")
            }
            .distinct().toList()
        if (candidates.isEmpty()) return null

        // One file per quality (prefer .mp4), so the app can offer 1080p / 720p / 480p ...
        val byHeight: Map<Int, String> = candidates
            .filter { heightOf(it) > 0 }
            .groupBy { heightOf(it) }
            .mapValues { (_, list) -> list.firstOrNull { it.lowercase().contains(".mp4") } ?: list.first() }

        val best: String = if (byHeight.isNotEmpty()) {
            byHeight.maxByOrNull { it.key }!!.value
        } else {
            candidates.maxWithOrNull(
                compareBy<String>({ if (it.lowercase().contains(".mp4")) 1 else 0 })
            ) ?: return null
        }

        val sizes: Map<Int, Long> = byHeight.mapValues { (_, u) -> probe(u, pageUrl)?.total ?: 0L }
        val bestSize: Long = if (byHeight.isNotEmpty()) {
            sizes[byHeight.keys.max()] ?: 0L
        } else {
            probe(best, pageUrl)?.total ?: 0L
        }

        val rawTitle = meta(text, "og:title")
            ?: Regex("<title>([^<]*)</title>", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)
            ?: "Video"
        val title = Html.fromHtml(rawTitle, Html.FROM_HTML_MODE_LEGACY).toString().trim().ifBlank { "Video" }

        return VideoMeta(
            url = best,
            title = title,
            thumbnail = meta(text, "og:image"),
            durationSec = 0,
            heights = byHeight.keys.sortedDescending(),
            extractorArgs = null,
            referer = pageUrl,
            variants = byHeight,
            sizes = sizes,
            bestSize = bestSize,
            direct = !best.lowercase().contains(".m3u8")
        )
    }

    /** Instagram / Pinterest photo posts: use the page's main image. */
    fun scrapeImage(pageUrl: String, cookie: String? = null): VideoMeta? {
        val page = get(pageUrl, referer = pageUrl, cookie = cookie) ?: return null
        val text = page.body.replace("&amp;", "&")
        val img = meta(text, "og:image") ?: return null
        if (!img.startsWith("http")) return null

        val alts = mutableListOf<String>()
        var best = img
        if (img.contains("pinimg.com")) {
            val original = img.replace(Regex("""pinimg\.com/\d+x/"""), "pinimg.com/originals/")
            if (original != img) {
                best = original
                alts += img
            }
        }
        val rawTitle = meta(text, "og:title") ?: "Image"
        val title = Html.fromHtml(rawTitle, Html.FROM_HTML_MODE_LEGACY).toString().trim()
            .ifBlank { "Image" }
        return VideoMeta(
            url = best,
            title = title,
            thumbnail = img,
            durationSec = 0,
            heights = emptyList(),
            referer = pageUrl,
            isImage = true,
            altUrls = alts
        )
    }

    /** Downloads the image of [m] into [dir] and returns the file. */
    fun downloadImage(m: VideoMeta, dir: File, cookie: String? = null): File? {
        val base = m.title.replace(Regex("""[^\p{L}\p{N} _-]"""), "").trim().take(60).ifBlank { "image" }
        for (u in listOf(m.url) + m.altUrls) {
            val conn = try {
                URL(u).openConnection() as HttpURLConnection
            } catch (_: Exception) {
                continue
            }
            try {
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.setRequestProperty("User-Agent", UA)
                m.referer?.let { conn.setRequestProperty("Referer", it) }
                if (cookie != null) conn.setRequestProperty("Cookie", cookie)
                if (conn.responseCode != 200) continue
                val type = conn.contentType.orEmpty().lowercase()
                val ext = when {
                    type.contains("png") -> "png"
                    type.contains("webp") -> "webp"
                    else -> "jpg"
                }
                val out = File(dir, "$base.$ext")
                conn.inputStream.use { ins -> out.outputStream().use { ins.copyTo(it) } }
                if (out.length() > 0) return out
            } catch (_: Exception) {
                // try the next candidate
            } finally {
                conn.disconnect()
            }
        }
        return null
    }

    /** Asks the server for the file size and whether it supports ranged (parallel) downloads. */
    fun probe(url: String, referer: String?): Probe? {
        val conn = try {
            URL(url.replace(Regex("^http://"), "https://")).openConnection() as HttpURLConnection
        } catch (_: Exception) {
            return null
        }
        return try {
            conn.instanceFollowRedirects = true
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept-Encoding", "identity")
            conn.setRequestProperty("Range", "bytes=0-0")
            if (referer != null) conn.setRequestProperty("Referer", referer)
            val code = conn.responseCode
            val final = conn.url.toString()
            when (code) {
                206 -> {
                    val total = conn.getHeaderField("Content-Range")
                        ?.substringAfter("/")?.trim()?.toLongOrNull() ?: 0L
                    Probe(total, true, final)
                }
                200 -> Probe(maxOf(conn.contentLengthLong, 0L), false, final)
                else -> null
            }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchRange(
        url: String, referer: String?, start: Long, end: Long,
        raf: RandomAccessFile, done: AtomicLong
    ): Boolean {
        repeat(3) {
            var got = 0L
            val conn = try {
                URL(url).openConnection() as HttpURLConnection
            } catch (_: Exception) {
                return false
            }
            try {
                conn.connectTimeout = 15_000
                conn.readTimeout = 20_000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Accept-Encoding", "identity")
                conn.setRequestProperty("Range", "bytes=$start-$end")
                if (referer != null) conn.setRequestProperty("Referer", referer)
                val code = conn.responseCode
                if (code == 206) {
                    raf.seek(start)
                    conn.inputStream.use { ins ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            raf.write(buf, 0, r)
                            got += r
                            done.addAndGet(r.toLong())
                        }
                    }
                    if (got == end - start + 1) return true
                } else if (code != 429 && code !in 500..599) {
                    return false
                }
            } catch (_: Exception) {
                // retry this chunk
            } finally {
                conn.disconnect()
            }
            done.addAndGet(-got)
        }
        return false
    }

    /**
     * Fast download: many parallel connections on one file (like a download manager).
     * Returns false if the server does not support it, so the caller can fall back to yt-dlp.
     */
    suspend fun downloadParallel(
        url: String,
        referer: String?,
        dest: File,
        connections: Int = 16,
        onProgress: (done: Long, total: Long, speed: Long) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val probe = probe(url, referer) ?: return@withContext false
        val total = probe.total
        if (total <= 0L || !probe.ranges) return@withContext false
        val finalUrl = probe.finalUrl

        RandomAccessFile(dest, "rw").use { it.setLength(total) }
        val done = AtomicLong(0)
        val next = AtomicLong(0)
        val failed = AtomicBoolean(false)

        coroutineScope {
            val ticker = launch {
                var lastBytes = 0L
                var lastTime = System.currentTimeMillis()
                var speed = 0L
                while (isActive) {
                    delay(500)
                    val now = System.currentTimeMillis()
                    val bytes = done.get()
                    val dt = (now - lastTime).coerceAtLeast(1L)
                    val inst = (bytes - lastBytes) * 1000 / dt
                    speed = if (speed == 0L) inst else (speed * 0.6 + inst * 0.4).toLong()
                    lastBytes = bytes
                    lastTime = now
                    onProgress(bytes, total, speed)
                }
            }
            val workers = (0 until connections).map { _ ->
                async {
                    RandomAccessFile(dest, "rw").use { raf ->
                        var go = true
                        while (go && isActive && !failed.get()) {
                            val start = next.getAndAdd(CHUNK)
                            if (start >= total) {
                                go = false
                            } else {
                                val end = minOf(start + CHUNK - 1, total - 1)
                                if (!fetchRange(finalUrl, referer, start, end, raf, done)) {
                                    failed.set(true)
                                }
                            }
                        }
                    }
                }
            }
            workers.awaitAll()
            ticker.cancel()
        }
        !failed.get() && done.get() >= total
    }
}
