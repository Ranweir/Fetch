package com.vidsnap.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/** Instagram glyph: rounded square, lens circle and flash dot (tinted by the Icon). */
val InstagramIcon: ImageVector by lazy {
    ImageVector.Builder(
        name = "Instagram",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        // Rounded square outline
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(8.5f, 3f)
            lineTo(15.5f, 3f)
            arcTo(5.5f, 5.5f, 0f, false, true, 21f, 8.5f)
            lineTo(21f, 15.5f)
            arcTo(5.5f, 5.5f, 0f, false, true, 15.5f, 21f)
            lineTo(8.5f, 21f)
            arcTo(5.5f, 5.5f, 0f, false, true, 3f, 15.5f)
            lineTo(3f, 8.5f)
            arcTo(5.5f, 5.5f, 0f, false, true, 8.5f, 3f)
            close()
        }
        // Lens circle
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(16.2f, 12f)
            arcTo(4.2f, 4.2f, 0f, true, true, 7.8f, 12f)
            arcTo(4.2f, 4.2f, 0f, true, true, 16.2f, 12f)
            close()
        }
        // Flash dot
        path(fill = SolidColor(Color.Black)) {
            moveTo(18.4f, 6.7f)
            arcTo(1.1f, 1.1f, 0f, true, true, 16.2f, 6.7f)
            arcTo(1.1f, 1.1f, 0f, true, true, 18.4f, 6.7f)
            close()
        }
    }.build()
}
