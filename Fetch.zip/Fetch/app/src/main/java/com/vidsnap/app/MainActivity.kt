package com.vidsnap.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestHighestRefreshRate()
        askPermissions()
        handleIntent(intent)

        setContent {
            VidSnapTheme(vm.themeMode) {
                var showLogin by remember { mutableStateOf(false) }
                if (showLogin) {
                    InstagramLoginScreen(
                        onClose = { saved ->
                            showLogin = false
                            if (saved) vm.message = "Instagram login saved"
                        }
                    )
                } else {
                    HomeScreen(vm = vm, onLogin = { showLogin = true })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { vm.onSharedText(it) }
        }
    }

    /**
     * Compose animations are vsync-driven, so they run at whatever rate the window gets.
     * Many phones keep apps at 60 Hz unless asked, so ask for the display's highest mode
     * (120 Hz on a 120 Hz panel, 90 on a 90 Hz one, 60 on a 60 Hz one).
     */
    @Suppress("DEPRECATION")
    private fun requestHighestRefreshRate() {
        try {
            val display = windowManager.defaultDisplay ?: return
            val current = display.mode
            val best = display.supportedModes
                .filter {
                    it.physicalWidth == current.physicalWidth &&
                        it.physicalHeight == current.physicalHeight
                }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            if (Build.VERSION.SDK_INT >= 30) lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        } catch (_: Exception) {
        }
    }

    private fun askPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) needed += Manifest.permission.POST_NOTIFICATIONS

        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) needed += Manifest.permission.WRITE_EXTERNAL_STORAGE

        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }
}
