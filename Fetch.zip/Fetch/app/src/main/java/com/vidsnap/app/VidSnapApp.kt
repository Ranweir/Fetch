package com.vidsnap.app

import android.app.Application

class VidSnapApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Engine.init(this)
    }
}
