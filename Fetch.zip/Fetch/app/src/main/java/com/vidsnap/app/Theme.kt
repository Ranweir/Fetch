package com.vidsnap.app

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** All colours used by the "liquid glass" look, for one mode. */
@Immutable
class GlassColors(
    val dark: Boolean,
    val bg: List<Color>,
    val blobs: List<Color>,
    val glassFill: List<Color>,
    val glassBorder: List<Color>,
    val sheen: Color,
    val text: Color,
    val textDim: Color,
    val accent: List<Color>,
    val onAccent: Color,
    val fieldFill: Color,
    val fieldText: Color,
    val fieldHint: Color,
    val ringColors: List<Color>,
    val ringTrack: Color,
    val shadow: Color,
    val glow: Color,
    val danger: Color
)

val DarkGlass = GlassColors(
    dark = true,
    bg = listOf(Color(0xFF080B14), Color(0xFF15122B)),
    blobs = listOf(Color(0x5522D3EE), Color(0x558B5CF6), Color(0x44F472B6)),
    glassFill = listOf(Color(0x24FFFFFF), Color(0x08FFFFFF)),
    glassBorder = listOf(Color(0xAA22D3EE), Color(0x88A78BFA), Color(0xAAF472B6)),
    sheen = Color(0x1AFFFFFF),
    text = Color(0xFFF1F3FA),
    textDim = Color(0xFFA9AFC7),
    accent = listOf(Color(0xFF2EE6F0), Color(0xFF3B82F6)),
    onAccent = Color(0xFF03131F),
    fieldFill = Color(0xFFEEF1FA),
    fieldText = Color(0xFF14161F),
    fieldHint = Color(0xFF6B7188),
    ringColors = listOf(Color(0xFF22D3EE), Color(0xFF8B5CF6), Color(0xFFF472B6), Color(0xFF22D3EE)),
    ringTrack = Color(0x26FFFFFF),
    shadow = Color(0xFF000000),
    glow = Color(0xFF22D3EE),
    danger = Color(0xFFFF6B7A)
)

val LightGlass = GlassColors(
    dark = false,
    bg = listOf(Color(0xFFF6F0E8), Color(0xFFDCE1F3)),
    blobs = listOf(Color(0x55818CF8), Color(0x5567E8D4), Color(0x55FDBA74)),
    glassFill = listOf(Color(0x99FFFFFF), Color(0x40FFFFFF)),
    glassBorder = listOf(Color(0xFFFFFFFF), Color(0x88C4B5FD), Color(0xAA99F6E4)),
    sheen = Color(0x55FFFFFF),
    text = Color(0xFF1A1B25),
    textDim = Color(0xFF5B6075),
    accent = listOf(Color(0xFF6366F1), Color(0xFF8B8DF8)),
    onAccent = Color.White,
    fieldFill = Color(0xEEFFFFFF),
    fieldText = Color(0xFF1A1B25),
    fieldHint = Color(0xFF7B8096),
    ringColors = listOf(Color(0xFF6366F1), Color(0xFF67E8D4), Color(0xFFFDBA74), Color(0xFF6366F1)),
    ringTrack = Color(0x22000000),
    shadow = Color(0xFF6366F1),
    glow = Color(0xFF6366F1),
    danger = Color(0xFFD6334A)
)

val LocalGlass = staticCompositionLocalOf { DarkGlass }

@Composable
fun VidSnapTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val g = if (dark) DarkGlass else LightGlass

    val scheme = if (dark) {
        darkColorScheme(
            primary = g.accent[0], onPrimary = g.onAccent,
            background = g.bg[0], onBackground = g.text,
            surface = g.bg[1], onSurface = g.text,
            surfaceContainer = Color(0xFF1C1E31),
            error = g.danger
        )
    } else {
        lightColorScheme(
            primary = g.accent[0], onPrimary = g.onAccent,
            background = g.bg[0], onBackground = g.text,
            surface = Color(0xFFF3F1FA), onSurface = g.text,
            surfaceContainer = Color(0xFFF3F1FA),
            error = g.danger
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(
        LocalGlass provides g,
        LocalContentColor provides g.text
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
