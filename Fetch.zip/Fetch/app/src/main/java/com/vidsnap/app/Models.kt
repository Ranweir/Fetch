package com.vidsnap.app

data class VideoMeta(
    val url: String,
    val title: String,
    val thumbnail: String?,
    val durationSec: Int,
    val heights: List<Int>
)

sealed class Quality {
    object Best : Quality()
    data class Height(val px: Int) : Quality()
    object AudioMp3 : Quality()

    val label: String
        get() = when (this) {
            Best -> "Best"
            is Height -> "${px}p"
            AudioMp3 -> "Audio MP3"
        }
}

enum class Status { RUNNING, DONE, FAILED, CANCELLED }

data class DownloadItem(
    val id: String,
    val title: String,
    val thumbnail: String?,
    val status: Status = Status.RUNNING,
    val progress: Float = 0f,
    val note: String = "Starting…",
    val uri: String? = null,
    val mime: String? = null
)
