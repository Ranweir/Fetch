package com.vidsnap.app

data class VideoMeta(
    val url: String,
    val title: String,
    val thumbnail: String?,
    val durationSec: Int,
    val heights: List<Int>,
    val extractorArgs: String? = null,
    val referer: String? = null,
    val isImage: Boolean = false,
    val altUrls: List<String> = emptyList(),
    /** Direct files found in a page, by height (e.g. 720 -> url). Used when yt-dlp has no format list. */
    val variants: Map<Int, String> = emptyMap(),
    /** File size in bytes per height (0 / missing = unknown). */
    val sizes: Map<Int, Long> = emptyMap(),
    val bestSize: Long = 0L,
    val audioSize: Long = 0L,
    /** True when [url] is a plain downloadable file (can use the fast multi-connection downloader). */
    val direct: Boolean = false
)

fun VideoMeta.sizeFor(q: Quality): Long = when (q) {
    Quality.Best -> if (heights.isNotEmpty()) (sizes[heights.first()] ?: bestSize) else bestSize
    is Quality.Height -> sizes[q.px] ?: 0L
    Quality.AudioMp3 -> audioSize
}

fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> String.format(java.util.Locale.US, "%.2f GB", gb)
        mb >= 1 -> String.format(java.util.Locale.US, "%.1f MB", mb)
        kb >= 1 -> String.format(java.util.Locale.US, "%.0f KB", kb)
        else -> "$bytes B"
    }
}

fun formatEta(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return when {
        h > 0 -> "${h}h ${m}m"
        m > 0 -> "${m}m ${s}s"
        else -> "${s}s"
    }
}

fun progressNote(done: Long, total: Long, speed: Long): String {
    val pct = if (total > 0) (done * 100 / total).toInt() else 0
    return buildString {
        append("$pct% • ${formatSize(done)} / ${formatSize(total)}")
        if (speed > 0) {
            append(" • ${formatSize(speed)}/s")
            append(" • ${formatEta((total - done) / speed)} left")
        }
    }
}

sealed class Quality {
    object Best : Quality()
    data class Height(val px: Int) : Quality()
    object AudioMp3 : Quality()

    val label: String
        get() = when (this) {
            Best -> "Best"
            is Height -> "${px}p"
            AudioMp3 -> "Audio MP3"
        }
}

enum class Status { RUNNING, DONE, FAILED, CANCELLED }

data class DownloadItem(
    val id: String,
    val title: String,
    val thumbnail: String?,
    val status: Status = Status.RUNNING,
    val progress: Float = 0f,
    val note: String = "Starting…",
    val uri: String? = null,
    val mime: String? = null
)

/** The four tabs of the app. */
enum class Site(
    val label: String,
    val placeholder: String,
    val button: String,
    val tip: String
) {
    YOUTUBE(
        "YouTube", "Paste a YouTube link", "Fetch video",
        "Videos, Shorts and music. Pick a quality or Audio MP3. Share → Fetch from the YouTube app also works."
    ),
    INSTAGRAM(
        "Instagram", "Paste an Instagram reel / video / post link", "Fetch video / post",
        "Reels, videos and photo posts. Most links need login — use the login button above (stories and private posts too)."
    ),
    PINTEREST(
        "Pinterest", "Paste a Pinterest or pin.it link", "Fetch pin",
        "Video and image pins. Short pin.it links work too."
    ),
    WEBSITE(
        "Website", "Paste a video page link from any website", "Fetch video",
        "Any other site: yt-dlp supports 1000+ sites, and Fetch also tries to find the video file inside the page."
    );

    companion object {
        fun detect(url: String): Site {
            val low = url.trim().lowercase()
            val host = try {
                java.net.URI(low).host.orEmpty()
            } catch (_: Exception) {
                ""
            }.ifEmpty { low }
            return when {
                host.contains("youtube.com") || host.contains("youtu.be") ||
                    host.contains("youtube-nocookie") -> YOUTUBE
                host.contains("instagram.com") || host.contains("instagr.am") -> INSTAGRAM
                host.contains("pinterest.") || host.contains("pin.it") -> PINTEREST
                else -> WEBSITE
            }
        }
    }
}
