package com.vidsnap.app

import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage

@Composable
fun HomeScreen(vm: MainViewModel, onLogin: () -> Unit) {
    val items by DownloadManager.items.collectAsState()
    val ready by Engine.ready.collectAsState()
    val engineError by Engine.error.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val g = LocalGlass.current

    LaunchedEffect(vm.message) {
        vm.message?.let {
            snackbar.showSnackbar(it)
            vm.message = null
        }
    }

    GlassBackground {
        Column(Modifier.fillMaxSize()) {
            Header(vm, onLogin)

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .imePadding(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (engineError != null) {
                    item {
                        GlassCard { Text(engineError!!, color = g.danger) }
                    }
                } else if (!ready) {
                    item {
                        GlassCard {
                            Text("Preparing download engine…", color = g.textDim, fontSize = 13.sp)
                            GlassProgressBar(progress = 0.35f)
                        }
                    }
                }

                item { TabBar(vm) }

                item { LinkCard(vm, ready, onLogin) }

                vm.meta?.let { m -> item { PreviewCard(vm, m) } }

                if (items.isEmpty() && vm.meta == null) {
                    item {
                        GlassCard {
                            Text("Quick tip", fontWeight = FontWeight.SemiBold)
                            Text(
                                vm.tab.tip,
                                color = g.textDim,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                if (items.isNotEmpty()) {
                    item {
                        Text(
                            "Downloads",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                        )
                    }
                    items(items, key = { it.id }) { DownloadRow(it) }
                }

                item { Spacer(Modifier.navigationBarsPadding()) }
            }
        }

        SnackbarHost(
            snackbar,
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
        )
    }
}

@Composable
private fun Header(vm: MainViewModel, onLogin: () -> Unit) {
    val g = LocalGlass.current
    var menu by remember { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Fetch", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .width(38.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(Brush.horizontalGradient(g.accent))
            )
        }

        GlassIconButton(
            icon = if (g.dark) Icons.Default.LightMode else Icons.Default.DarkMode,
            description = "Switch theme"
        ) { vm.setTheme(if (g.dark) ThemeMode.LIGHT else ThemeMode.DARK) }

        Spacer(Modifier.width(10.dp))

        Box {
            GlassIconButton(Icons.Default.MoreVert, "Menu") { menu = true }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Instagram login (stories / private)") },
                    onClick = { menu = false; onLogin() }
                )
                if (DownloadManager.hasInstagramLogin()) {
                    DropdownMenuItem(
                        text = { Text("Remove Instagram login") },
                        onClick = { menu = false; vm.clearInstagramLogin() }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Update download engine") },
                    onClick = { menu = false; vm.updateEngine() }
                )
                DropdownMenuItem(
                    text = { Text("Use system theme") },
                    onClick = { menu = false; vm.setTheme(ThemeMode.SYSTEM) }
                )
            }
        }
    }
}

@Composable
private fun TabBar(vm: MainViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Site.values().forEach { site ->
            GlassChip(label = site.label, selected = vm.tab == site, onClick = { vm.selectTab(site) })
        }
    }
}

@Composable
private fun LinkCard(vm: MainViewModel, ready: Boolean, onLogin: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    GlassCard {
        Text("${vm.tab.label} link", fontWeight = FontWeight.SemiBold)
        GlassField(
            value = vm.url,
            onValueChange = { vm.url = it },
            placeholder = vm.tab.placeholder,
            onSubmit = { if (ready) vm.fetch() },
            onPaste = { vm.url = clipboard.getText()?.text.orEmpty() },
            modifier = Modifier.fillMaxWidth()
        )
        if (vm.tab == Site.INSTAGRAM) {
            val loggedIn = DownloadManager.hasInstagramLogin()
            GlassChip(
                label = if (loggedIn) "Instagram login ✓" else "Instagram login (needed for most links)",
                selected = loggedIn,
                onClick = onLogin
            )
        }
        PillButton(
            text = if (vm.loading) "Reading link…" else vm.tab.button,
            onClick = { vm.fetch() },
            enabled = ready && vm.url.isNotBlank(),
            loading = vm.loading,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PreviewCard(vm: MainViewModel, m: VideoMeta) {
    val g = LocalGlass.current
    val qualities: List<Quality> =
        listOf(Quality.Best) + m.heights.map { Quality.Height(it) } + Quality.AudioMp3

    GlassCard {
        if (m.thumbnail != null) {
            AsyncImage(
                model = m.thumbnail,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(20.dp))
            )
        }
        Text(m.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
        if (m.durationSec > 0) {
            Text(formatDuration(m.durationSec), color = g.textDim, fontSize = 13.sp)
        }
        if (!m.isImage) {
            Text("Quality", color = g.textDim, fontSize = 13.sp)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                qualities.forEach { q ->
                    GlassChip(label = q.label, selected = vm.quality == q, onClick = { vm.quality = q })
                }
            }
        }
        PillButton(
            text = if (m.isImage) "Save image" else "Download ${vm.quality.label}",
            onClick = { vm.download() },
            icon = Icons.Default.Download,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun DownloadRow(item: DownloadItem) {
    val g = LocalGlass.current
    val ctx = LocalContext.current

    GlassCard(shape = RoundedCornerShape(22.dp), padding = 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Thumb(item)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    item.note,
                    color = if (item.status == Status.FAILED) g.danger else g.textDim,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (item.status == Status.RUNNING) {
                    Spacer(Modifier.height(2.dp))
                    GlassProgressBar(item.progress)
                }
            }
            when (item.status) {
                Status.RUNNING -> IconButton(onClick = { DownloadManager.cancel(item.id) }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = g.text)
                }
                Status.DONE -> {
                    if (item.uri != null) {
                        IconButton(onClick = {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(item.uri), item.mime)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }) { Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = g.text) }
                        IconButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).setType(item.mime ?: "video/*")
                                .putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            ctx.startActivity(Intent.createChooser(send, "Share"))
                        }) { Icon(Icons.Default.Share, contentDescription = "Share", tint = g.text) }
                    }
                    IconButton(onClick = { DownloadManager.dismiss(item.id) }) {
                        Icon(Icons.Default.Close, contentDescription = "Remove", tint = g.textDim)
                    }
                }
                else -> IconButton(onClick = { DownloadManager.dismiss(item.id) }) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = g.textDim)
                }
            }
        }
    }
}

/** Thumbnail with a progress ring while downloading and a check badge when done. */
@Composable
private fun Thumb(item: DownloadItem) {
    val g = LocalGlass.current
    Box(
        Modifier
            .size(64.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(g.ringTrack)
    ) {
        AsyncImage(
            model = item.thumbnail,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        when (item.status) {
            Status.RUNNING -> Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center
            ) {
                ProgressRing(
                    progress = item.progress.takeIf { it > 0.01f },
                    modifier = Modifier.size(42.dp)
                )
            }
            Status.DONE -> Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(Brush.horizontalGradient(g.accent)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = g.onAccent, modifier = Modifier.size(14.dp))
            }
            else -> Unit
        }
    }
}

@Composable
fun InstagramLoginScreen(onClose: (saved: Boolean) -> Unit) {
    val g = LocalGlass.current
    GlassBackground {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back") { onClose(false) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Instagram login", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Log in, then tap Done", color = g.textDim, fontSize = 12.sp)
                }
                PillButton(
                    text = "Done",
                    onClick = { onClose(DownloadManager.saveInstagramCookies()) },
                    height = 44.dp
                )
            }

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                    .navigationBarsPadding()
                    .glass(RoundedCornerShape(26.dp))
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            webViewClient = WebViewClient()
                            loadUrl("https://www.instagram.com/accounts/login/")
                        }
                    }
                )
            }
        }
    }
}

private fun formatDuration(sec: Int): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
