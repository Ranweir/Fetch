package com.vidsnap.app

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Initialises the bundled yt-dlp + ffmpeg runtime. */
object Engine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun init(app: Application) {
        DownloadManager.app = app
        scope.launch {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                _ready.value = true
            } catch (e: Exception) {
                _error.value = "Engine failed to start: ${e.message}"
            }
        }
    }

    /** Updates yt-dlp itself. Sites change often, so this fixes "download stopped working" issues. */
    suspend fun update(ctx: Context): String = withContext(Dispatchers.IO) {
        try {
            val status = YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.STABLE)
            "Engine update: ${status ?: "already latest"}"
        } catch (e: Exception) {
            "Update failed: ${e.message}"
        }
    }
}

object DownloadManager {
    lateinit var app: Application

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = HashMap<String, Job>()
    private val cancelled = HashSet<String>()

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    // ---------- Info / formats ----------

    suspend fun fetchInfo(url: String): VideoMeta = withContext(Dispatchers.IO) {
        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        applyCookies(req, url)
        val info = YoutubeDL.getInstance().getInfo(req)
        val heights = info.formats.orEmpty()
            .map { it.height }
            .filter { it > 0 }
            .distinct()
            .sortedDescending()
        VideoMeta(
            url = url,
            title = info.title ?: "Video",
            thumbnail = info.thumbnail,
            durationSec = info.duration,
            heights = heights
        )
    }

    // ---------- Download ----------

    fun enqueue(meta: VideoMeta, quality: Quality) {
        val id = UUID.randomUUID().toString()
        _items.update { listOf(DownloadItem(id, meta.title, meta.thumbnail)) + it }
        ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))

        jobs[id] = scope.launch {
            val tmp = File(app.cacheDir, "dl/$id").apply { mkdirs() }
            try {
                val req = YoutubeDLRequest(meta.url)
                req.addOption("--no-playlist")
                req.addOption("--no-mtime")
                req.addOption("-o", "${tmp.absolutePath}/%(title).80B.%(ext)s")
                applyCookies(req, meta.url)
                when (quality) {
                    Quality.Best -> {
                        req.addOption("-f", "bv*+ba/b")
                        req.addOption("--merge-output-format", "mp4")
                    }
                    is Quality.Height -> {
                        val h = quality.px
                        req.addOption(
                            "-f",
                            "bv*[height<=$h][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h]/b"
                        )
                        req.addOption("--merge-output-format", "mp4")
                    }
                    Quality.AudioMp3 -> {
                        req.addOption("-f", "ba/b")
                        req.addOption("-x")
                        req.addOption("--audio-format", "mp3")
                    }
                }

                YoutubeDL.getInstance().execute(req, id) { progress, eta, _ ->
                    if (progress >= 0f) {
                        patch(id) {
                            it.copy(
                                progress = (progress / 100f).coerceIn(0f, 1f),
                                note = "${progress.toInt()}%" + if (eta > 0) " • ${eta}s left" else ""
                            )
                        }
                    }
                }

                patch(id) { it.copy(note = "Saving…", progress = 1f) }
                val out = tmp.listFiles()
                    ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                    ?.maxByOrNull { it.length() }
                    ?: throw IllegalStateException("No file was produced")

                val saved = saveToPublic(out)
                patch(id) {
                    it.copy(
                        status = Status.DONE,
                        progress = 1f,
                        note = "Saved to ${if (isAudio(out)) "Music" else "Movies"}/Fetch",
                        uri = saved?.toString(),
                        mime = mimeOf(out)
                    )
                }
            } catch (e: CancellationException) {
                patch(id) { it.copy(status = Status.CANCELLED, note = "Cancelled") }
                throw e
            } catch (e: Exception) {
                if (id in cancelled) {
                    patch(id) { it.copy(status = Status.CANCELLED, note = "Cancelled") }
                } else {
                    patch(id) {
                        it.copy(status = Status.FAILED, note = (e.message ?: "Download failed").take(200))
                    }
                }
            } finally {
                tmp.deleteRecursively()
                jobs.remove(id)
                cancelled.remove(id)
                if (_items.value.none { it.status == Status.RUNNING }) {
                    app.stopService(Intent(app, DownloadService::class.java))
                }
            }
        }
    }

    fun cancel(id: String) {
        cancelled.add(id)
        try {
            YoutubeDL.getInstance().destroyProcessById(id)
        } catch (_: Exception) {
        }
        jobs[id]?.cancel()
    }

    fun dismiss(id: String) {
        _items.update { list -> list.filterNot { it.id == id } }
    }

    private fun patch(id: String, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    // ---------- Cookies (optional Instagram login for stories / private posts) ----------

    private fun cookieFile(): File = File(app.filesDir, "cookies_instagram.txt")

    fun hasInstagramLogin(): Boolean = cookieFile().exists()

    fun saveInstagramCookies(): Boolean {
        val raw = CookieManager.getInstance().getCookie("https://www.instagram.com") ?: return false
        if (!raw.contains("sessionid")) return false
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        raw.split(";").map { it.trim() }.filter { it.contains("=") }.forEach {
            val name = it.substringBefore("=")
            val value = it.substringAfter("=")
            sb.append(".instagram.com\tTRUE\t/\tTRUE\t2147483647\t$name\t$value\n")
        }
        cookieFile().writeText(sb.toString())
        return true
    }

    fun clearInstagramLogin() {
        cookieFile().delete()
    }

    private fun applyCookies(req: YoutubeDLRequest, url: String) {
        if (url.contains("instagram.com") && cookieFile().exists()) {
            req.addOption("--cookies", cookieFile().absolutePath)
        }
    }

    // ---------- Saving to public storage ----------

    private fun isAudio(f: File) = f.extension.lowercase() in setOf("mp3", "m4a", "opus", "ogg", "aac", "wav")

    private fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase())
            ?: if (isAudio(f)) "audio/*" else "video/*"

    private fun saveToPublic(file: File): Uri? {
        val audio = isAudio(file)
        val mime = mimeOf(file)
        val resolver = app.contentResolver

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    (if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/Fetch"
                )
            }
            val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val uri = resolver.insert(collection, values) ?: return null
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            return uri
        }

        @Suppress("DEPRECATION")
        val dir = File(
            Environment.getExternalStoragePublicDirectory(
                if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
            ), "Fetch"
        ).apply { mkdirs() }
        val dest = File(dir, file.name)
        file.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(app, arrayOf(dest.absolutePath), arrayOf(mime), null)
        return null
    }
}
