package com.fetch.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Frosted-glass surface: translucent gradient fill, glowing gradient border, soft sheen and shadow. */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(26.dp),
    elevation: Dp = 14.dp
): Modifier = composed {
    val g = LocalGlass.current
    this
        .shadow(elevation, shape, clip = false, ambientColor = g.shadow, spotColor = g.shadow)
        .clip(shape)
        .background(Brush.linearGradient(g.glassFill), shape)
        .drawBehind {
            drawRect(
                Brush.verticalGradient(listOf(g.sheen, Color.Transparent), endY = size.height * 0.45f)
            )
        }
        .border(1.dp, Brush.linearGradient(g.glassBorder), shape)
}

private fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(cx, cy), radius = r),
        radius = r,
        center = Offset(cx, cy)
    )
}

/** Gradient background with soft colour blobs that the glass panels sit on. */
@Composable
fun GlassBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val g = LocalGlass.current
    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(g.bg))
            .drawBehind {
                blob(g.blobs[0], size.width * 0.10f, size.height * 0.08f, size.width * 0.95f)
                blob(g.blobs[1], size.width * 0.98f, size.height * 0.45f, size.width * 0.85f)
                blob(g.blobs[2], size.width * 0.20f, size.height * 0.96f, size.width * 0.95f)
            },
        content = content
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(26.dp),
    padding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .glass(shape)
            .padding(padding),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    loading: Boolean = false,
    height: Dp = 54.dp
) {
    val g = LocalGlass.current
    val fg = if (primary) g.onAccent else g.text
    val base = modifier
        .height(height)
        .alpha(if (enabled) 1f else 0.45f)
    val styled = if (primary) {
        base
            .shadow(16.dp, CircleShape, clip = false, ambientColor = g.glow, spotColor = g.glow)
            .clip(CircleShape)
            .background(Brush.horizontalGradient(g.accent), CircleShape)
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.05f))),
                CircleShape
            )
    } else {
        base.glass(CircleShape, 8.dp)
    }
    Row(
        styled
            .clickable(enabled = enabled && !loading, onClick = onClick)
            .padding(horizontal = 24.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(20.dp), color = fg, strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
        } else if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun GlassChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val g = LocalGlass.current
    val base = Modifier.height(40.dp)
    val styled = if (selected) {
        base
            .shadow(10.dp, CircleShape, clip = false, ambientColor = g.glow, spotColor = g.glow)
            .clip(CircleShape)
            .background(Brush.horizontalGradient(g.accent), CircleShape)
    } else {
        base.glass(CircleShape, 4.dp)
    }
    Box(
        styled
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) g.onAccent else g.text,
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp
        )
    }
}

@Composable
fun GlassIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    val g = LocalGlass.current
    Box(
        Modifier
            .size(44.dp)
            .glass(CircleShape, 8.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = g.text, modifier = Modifier.size(22.dp))
    }
}

/** Light pill-shaped input, like the search bar in the kit. */
@Composable
fun GlassField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    onSubmit: () -> Unit,
    onPaste: () -> Unit,
    modifier: Modifier = Modifier
) {
    val g = LocalGlass.current
    Row(
        modifier
            .height(56.dp)
            .shadow(10.dp, CircleShape, clip = false, ambientColor = g.shadow, spotColor = g.shadow)
            .clip(CircleShape)
            .background(g.fieldFill)
            .padding(start = 18.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Link, contentDescription = null, tint = g.fieldHint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(placeholder, color = g.fieldHint, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = TextStyle(color = g.fieldText, fontSize = 16.sp),
                cursorBrush = SolidColor(g.fieldText),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onSubmit() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
        IconButton(onClick = { if (value.isEmpty()) onPaste() else onValueChange("") }) {
            Icon(
                if (value.isEmpty()) Icons.Default.ContentPaste else Icons.Default.Close,
                contentDescription = if (value.isEmpty()) "Paste" else "Clear",
                tint = g.fieldHint
            )
        }
    }
}

/** Gradient ring. progress == null shows a spinning arc. */
@Composable
fun ProgressRing(progress: Float?, modifier: Modifier = Modifier, stroke: Dp = 5.dp) {
    val g = LocalGlass.current
    val spin = rememberInfiniteTransition(label = "ring")
    val angle by spin.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "angle"
    )
    Canvas(modifier) {
        val s = stroke.toPx()
        val arcSize = Size(size.width - s, size.height - s)
        val topLeft = Offset(s / 2, s / 2)
        drawArc(
            color = g.ringTrack, startAngle = 0f, sweepAngle = 360f, useCenter = false,
            topLeft = topLeft, size = arcSize, style = Stroke(s)
        )
        val sweep = if (progress == null) 100f else 360f * progress.coerceIn(0f, 1f)
        rotate(if (progress == null) angle else -90f) {
            drawArc(
                brush = Brush.sweepGradient(g.ringColors), startAngle = 0f, sweepAngle = sweep,
                useCenter = false, topLeft = topLeft, size = arcSize,
                style = Stroke(s, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun GlassProgressBar(progress: Float, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val p by animateFloatAsState(progress.coerceIn(0.03f, 1f), label = "bar")
    Box(
        modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape)
            .background(g.ringTrack)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(p)
                .clip(CircleShape)
                .background(Brush.horizontalGradient(g.ringColors.take(3)))
        )
    }
}
