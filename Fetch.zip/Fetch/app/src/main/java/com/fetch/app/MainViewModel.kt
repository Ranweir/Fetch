package com.fetch.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("fetch", Context.MODE_PRIVATE)

    var tab by mutableStateOf(Site.YOUTUBE)
        private set
    private val urls = mutableStateMapOf<Site, String>()
    private val metas = mutableStateMapOf<Site, VideoMeta>()

    /** The link text of the currently selected tab. */
    var url: String
        get() = urls[tab].orEmpty()
        set(value) { urls[tab] = value }

    /** The fetched video of the currently selected tab. */
    val meta: VideoMeta? get() = metas[tab]

    fun urlFor(site: Site): String = urls[site].orEmpty()
    fun setUrl(site: Site, value: String) { urls[site] = value }
    fun metaFor(site: Site): VideoMeta? = metas[site]

    var loading by mutableStateOf(false)
    var quality by mutableStateOf<Quality>(Quality.Best)
    var message by mutableStateOf<String?>(null)

    var themeMode by mutableStateOf(
        ThemeMode.values().getOrElse(prefs.getInt("theme", 0)) { ThemeMode.SYSTEM }
    )
        private set

    fun setTheme(mode: ThemeMode) {
        themeMode = mode
        prefs.edit().putInt("theme", mode.ordinal).apply()
    }

    fun selectTab(site: Site) {
        tab = site
        quality = Quality.Best
    }

    fun fetch() {
        val link = url.trim()
        if (link.isBlank() || loading) return

        // Put the link on the tab it belongs to (e.g. a YouTube link pasted into Instagram).
        val target = Site.detect(link)
        if (target != tab) {
            urls[tab] = ""
            selectTab(target)
            urls[target] = link
            message = "Opened the ${target.label} tab"
        }

        loading = true
        metas.remove(target)
        viewModelScope.launch {
            try {
                val m = DownloadManager.fetchInfo(link)
                metas[target] = m
                quality = Quality.Best
            } catch (e: Exception) {
                message = "Couldn't read this link: ${(e.message ?: "unknown error").take(300)}"
            } finally {
                loading = false
            }
        }
    }

    fun download() {
        val m = meta ?: return
        DownloadManager.enqueue(m, quality)
        message = "Download started"
        metas.remove(tab)
        urls[tab] = ""
    }

    fun updateEngine() {
        viewModelScope.launch {
            message = "Updating engine…"
            message = Engine.update(getApplication())
        }
    }

    fun clearCache() {
        viewModelScope.launch { message = DownloadManager.clearCache() }
    }

    fun clearInstagramLogin() {
        DownloadManager.clearInstagramLogin()
        message = "Instagram login removed"
    }

    /** Called when a link is shared into the app. */
    fun onSharedText(text: String) {
        val found = Regex("https?://\\S+").find(text)?.value ?: return
        url = found
        fetch()
    }
}
