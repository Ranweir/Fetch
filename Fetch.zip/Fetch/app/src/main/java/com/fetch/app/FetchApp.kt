package com.fetch.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FetchApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        // Wipe leftovers of earlier runs off the main thread; nothing can be downloading yet.
        CoroutineScope(Dispatchers.IO).launch { CacheManager.cleanOnStart(this@FetchApp) }
        Engine.init(this)
    }

    /** Bounded thumbnail cache so images can never pile up in the app cache. */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.15).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve(CacheManager.IMAGE_DIR))
                    .maxSizeBytes(CacheManager.IMAGE_CACHE_BYTES)
                    .build()
            }
            .build()
}
