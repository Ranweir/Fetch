package com.fetch.app

import android.content.Context

/**
 * Keeps the app cache small.
 *
 * What fills the cache: half-finished downloads (cache/dl/<id>), the WebView cache from the
 * Instagram login page and thumbnails. Downloads cannot survive a process restart (their state
 * lives in memory), so anything still in cache/dl at start-up is dead weight.
 */
object CacheManager {
    /** Coil's thumbnail cache lives here; it is size-capped by Coil itself, so we never delete it by hand. */
    const val IMAGE_DIR = "image_cache"
    const val IMAGE_CACHE_BYTES = 24L * 1024 * 1024

    private const val DL_DIR = "dl"

    fun size(ctx: Context): Long =
        ctx.cacheDir.walkBottomUp().filter { it.isFile }.sumOf { it.length() }

    /**
     * Deletes everything in the cache except the thumbnail cache and the folders of downloads in
     * [keepIds] (paused downloads that can still be resumed). Returns the bytes freed.
     */
    fun clear(ctx: Context, keepIds: Set<String>): Long {
        val before = size(ctx)
        try {
            ctx.cacheDir.listFiles()?.forEach { f ->
                when (f.name) {
                    IMAGE_DIR -> Unit
                    DL_DIR -> f.listFiles()?.forEach { d ->
                        if (d.name !in keepIds) d.deleteRecursively()
                    }
                    else -> f.deleteRecursively()
                }
            }
        } catch (_: Exception) {
            // best effort
        }
        return (before - size(ctx)).coerceAtLeast(0L)
    }

    /** Called once when the process starts: nothing is running yet, so nothing needs to be kept. */
    fun cleanOnStart(ctx: Context) {
        clear(ctx, emptySet())
    }
}
