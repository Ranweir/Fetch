package com.fetch.app

import android.app.Activity
import android.os.Build
import android.view.Display

/**
 * Locks the window to the display's highest refresh rate (60, 90 or 120 Hz, whatever the phone
 * supports) at the current resolution. Without this many phones keep apps on 60 Hz or let the rate
 * drop while animating, which looks like lag.
 *
 * Uses the mode id (a hard request) and the matching rate together. Cheap to call repeatedly:
 * it returns early when the window already asks for that mode.
 */
object RefreshRate {
    @Suppress("DEPRECATION")
    fun lockToMax(activity: Activity) {
        try {
            val display: Display = (if (Build.VERSION.SDK_INT >= 30) activity.display
            else activity.windowManager.defaultDisplay) ?: return
            val current = display.mode
            val best = display.supportedModes
                .filter {
                    it.physicalWidth == current.physicalWidth &&
                        it.physicalHeight == current.physicalHeight
                }
                .maxByOrNull { it.refreshRate } ?: return

            val lp = activity.window.attributes
            if (lp.preferredDisplayModeId == best.modeId) return
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            activity.window.attributes = lp
        } catch (_: Exception) {
            // Some OEM builds throw here; the app still works at the system default rate.
        }
    }
}
