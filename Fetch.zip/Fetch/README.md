# Fetch

Android app (Kotlin + Jetpack Compose) that downloads videos from a pasted link.
It is powered by [yt-dlp](https://github.com/yt-dlp/yt-dlp) (via `youtubedl-android`) + ffmpeg.

## Features
- Paste a link (or use **Share → Fetch** from another app) and tap **Fetch video**
- **YouTube**: pick quality (Best / 2160p / 1440p / 1080p / 720p / … / Audio MP3)
- **Instagram**: reels, posts and stories. Stories / private content need the in-app login (menu → Instagram login)
- **Pinterest** and **any other site** that yt-dlp supports (1000+ sites), including direct video pages
- Background downloads with notification, progress, cancel, open and share
- Files are saved to `Movies/Fetch` (video) or `Music/Fetch` (MP3)
- **Liquid glass UI** in both dark and light mode (glass cards, pill buttons, gradient glow, progress ring). Follows the system theme; use the sun/moon button to switch, or menu → *Use system theme*
- Menu → **Update download engine** refreshes yt-dlp when a site stops working

## Build
**Option A – GitHub Actions (no Android Studio needed)**
1. Push this folder to a GitHub repository.
2. Open the **Actions** tab → *Build APK* → download the `Fetch-debug-apk` artifact.

**Option B – Android Studio**
Open the folder, let Gradle sync, then Run (minSdk 24, Android 7.0+).

## Notes
- Download only content you own or have permission to save. Platform terms of service and copyright laws apply.
- Some pages use DRM or heavy anti-bot protection; those cannot be downloaded.
- The Instagram login stays on your phone (cookies file in app storage) and is used only for Instagram links.
